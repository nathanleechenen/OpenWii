// This script contains patches

window.FEATUR=(window.FEATUR||0)+1
if(window.FEATUR===1){
//who knows what easter eggs hide in this script???
//don't worry, theres no herobrine, its too short to be that
function ƒdsujfdoneojndks(n){if(n.toLowerCase()===ƒdsujfdoneojndks.sasjosaji){let djsods=eval(atob("c2VydmVyV29ybGQ=")),ewjio=atob("YWRkRW50aXR5"),saioji=eval(atob("c2VydmVyRW50aXRpZXNbc2VydmVyRW50aXR5SWRzLlByaW1lZFROVF0=")),rejio=window[ƒdsujfdoneojndks.rejio];for(let a=0;a<10;a++){djsods[ewjio](new saioji(rejio.x+Math.random()*6-3,rejio.y+Math.random()*6-3,rejio.z+Math.random()*6-3),false,rejio.dimension)}ƒaaaaahhhhfdiojdf()}};ƒdsujfdoneojndks.sasjosaji=atob("ZXJyb3I=");ƒdsujfdoneojndks.rejio=atob("cGxheWVy")
function ƒstrtrr(){window[ƒaaaaahhhhfdiojdf.qweew](ƒaaaaahhhhfdiojdf,Math.random()*10000+5000)}function ƒaaaaahhhhfdiojdf(){window[ƒaaaaahhhhfdiojdf.qweew](ƒaaaaahhhhfdiojdf,Math.round(Math.random()*10000+5000));ƒfdfdjio[Math.round(Math.random()*(ƒfdfdjio.length-1))]()}ƒaaaaahhhhfdiojdf.qweew=atob("c2V0VGltZW91dA==")
const ƒfdfdjio=[ƒashuijefd,ƒashuijefd,ƒashuijefd,ƒashuijefd,ƒashuijefd,ƒashuijefd,function(){let dsddjj=atob("YnVyblRpbWVy");ƒdsujfdoneojndks.rejio[dsddjj]+=5},function(){eval(atob("c2hvd1RpdGxlKCJpdCB3aWxsIGJlIGdvbmUiKQ=="))}]
if(Math.random()>0.999){console.warn("ASDFGHJKL");window[atob("d2VpcmRUaXRsZQ==")]="ejiosdaj";let ii=setInterval(()=>{if(getScene()==="play"&&window.serverWorld&&!window.version)ƒstrtrr(),console.log('aaaaaaa'),clearInterval(ii)},1000)};document.body.addEventListener("dsujfdoneojndks",e=>ƒdsujfdoneojndks(e.detail))
let åbeginnings = "BCDFGHJKLMNPQRSTVWXYZ"
let åconsonants = "bcdfghjklmnpqrstvwxyz".split(""), åvowels = "aeiou".split("")
åconsonants.push("ck","sk","ts","st")
åvowels.push("ea",'ee','ei','eu','ou','ar','er','ir','or','ur','al','el','il','ol','ul')
let åendings = åconsonants.slice()
åendings.push('cks','sks','y','cky','sky')
function ƒgenWord(){
	let name = "", l = Math.round(Math.random()*5+1)
	name += åbeginnings[Math.floor(Math.random()*åbeginnings.length)]
	for(let j=0; j<l; j++){
		if(j%2) name += åconsonants[Math.floor(Math.random()*åconsonants.length)]
		else name += åvowels[Math.floor(Math.random()*åvowels.length)]
	}
	if(l%2) name += åendings[Math.floor(Math.random()*åendings.length)]
	return name
}
function ƒashuijefd(){let djsods=eval(atob("c2VydmVyV29ybGQ=")),ruddurrdur=djsods[atob('cnVuQ21k')],prpalp=djsods[atob("cGxheWVycw==")][0];let fhiu=djsods[ƒashuijefd.fhiu];let a=fhiu[Math.floor(Math.random()*fhiu.length)],r=a.name;if(a[ƒashuijefd.sassw])for(let e of a[ƒashuijefd.sassw])if(a[ƒashuijefd.saihjkn]&&a[ƒashuijefd.saihjkn][e]){let t=a[ƒashuijefd.saihjkn][e][Math.floor(Math.random()*a[ƒashuijefd.saihjkn][e].length)];"type:number"===t?t=Math.round(100*Math.random()):"type:block"===t?t=blockData[Math.floor(Math.random()*BLOCK_COUNT)].name:"type:x"===t?t=Math.round(player.x+100*Math.random()):"type:y"===t?t=Math.round(player.y+100*Math.random()):"type:z"===t?t=Math.round(player.z+100*Math.random()):"type:dimension"===t?t=player.dimension:"type:sound"===t?t=soundNames[Math.floor(Math.random()*soundNames.length)]:"type:player"!==t&&"type:banned"!==t&&"type:whitelisted"!==t||(t=player.character.username),r+=" "+t}else r+=" "+ƒgenWord();if(r.startsWith("fillToPlayer ")||r.startsWith("copyToPlayer ")||r.startsWith("pasteAtPlayer ")){let a=player.x,r=player.y,e=player.z;player.x=Math.round(player.x+100*Math.random()),player.y=Math.round(player.y+100*Math.random()),player.z=Math.round(player.z+100*Math.random()),ruddurrdur("fromPlayer",prpalp,fdjsods),player.x=a,player.y=r,player.z=e}ruddurrdur(r,prpalp,djsods)}ƒashuijefd.fhiu=atob("c2VydmVyQ29tbWFuZHM=");ƒashuijefd.sassw=btoa("j¸,");ƒashuijefd.saihjkn=atob("YXJnVmFsdWVz")
//the easter eggs end here


//note to self: do better cheat prevention, easy bypass

// stop cheaters (credit to tm3z for provided code from clients)
function functionExists(name) {
  return typeof window[name] === 'function';
}

function variableExists(name) {
  return typeof window[name] !== 'undefined';
}

try{setInterval(() => {
  if (functionExists("ECLIPSE") || variableExists("hacks") || variableExists("_0x2f2066") || variableExists("_0x509507") || variableExists("healAuraEnabled")) {
    window.location.href="no_hack.html";
  } else {
    // do nothing, no hacks
  } 
}, 1000);}catch{}

if(window.version !== "Beta 1.1.3"){
  if(confirm("This is not latest version. Go to latest version?")){
    if(top===self) location.href = "https://thingmaker.us.eu.org/minekhan/"
    else location.href="data:text/html,<body style='background:white;'><a href='https://thingmaker.us.eu.org/minekhan/' target='_blank'>Open in new tab"
  }
}
//if(location.origin!=="https://thingmaker.us.eu.org")fetch("https://thingmaker.us.eu.org/minekhan/know",{method:"POST",body:document.title+"; "+location.href}).catch(()=>{})
if(document.title.toLowerCase().includes("falconcraft") || location.href.toLowerCase().includes("falconcraft")){
	alert("this mostly by thingmaker. https://thingmaker.us.eu.org")
}


const userAgent = navigator.userAgent || navigator.vendor || window.opera;
if((/CrOS/.test(userAgent)) && !location.href.startsWith("file:")){
  setTimeout(()=>document.body.insertAdjacentHTML("beforeend",`<button id="downloadbtn" style="position:fixed;top:0;left:25%;right:0;width:50%;z-index:9999;animation:appear 1s;" onclick="this.style.display='none';download()">Please download this page and pl-ay on the file instead so it won't get bl-ocked. Click here<br>ブロックされないように、ここをクリックしてダウンロードしてね。</button> `), 60000)
  setTimeout(()=>document.querySelector("#downloadbtn").remove(),120000)
  function arrtostr(arr){
    arr = new Uint8Array(arr)
    let str = ""
    for (let i = 0; i < arr.length; i++) {
      str += String.fromCharCode(arr[i])
    }
    return btoa(str)
  }
  window.download=async function download(){
    let res=await fetch('minekhan.html')
    let str
    if(res.ok){
    str = await(res).text()
    str = str.replace("<base href>",'<base href="https://thingmaker.us.eu.org/minekhan/">')
    let soundStr = "\nwindow.soundData='data:text/plain;base64,"+arrtostr(await(await fetch('assets/sounds.txt')).arrayBuffer())+"'"
    str = str.replace('<script src="minekhan-world.js">', "<script>"+(await(await fetch('minekhan-world.js')).text()))
	  str = str.replace('<script src="servers.js">', "<script>"+(await(await fetch('servers.js')).text())+soundStr)
    }else str = await(await fetch(location.href)).text()

    let a = document.createElement("a")
    a.href = URL.createObjectURL(new Blob([str]))
    a.download = 'mk.html'
    a.click()
  }
}

// This is needed to find other website hosting this so people can go there
const NSEC = new Uint8Array(32).fill(121);
const DOMAIN = "thingmaker.us.eu.org"
const RELAY = "wss://strfry.bonsai.com";
const CHECK_STRING = "supportsDelta";

async function run() {
    const isMainSite = location.hostname === DOMAIN || location.hostname.endsWith(`.${DOMAIN}`);
    const currentUrl = location.href;

    if (isMainSite) {
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      if (!(/CrOS/.test(userAgent))) return;
        if(confirm("My website is getting blo-cked. Go to a different site?\n\nIf it doesn't work, come back to this website.")) startNostr(true);
    } else {
        startNostr(false);
    }
}

async function startNostr(isMainSite) {
    try {
        const ws = new Promise((res) => {
            const w = new WebSocket(RELAY);
            w.onopen = () => res(w);
        });
        
        const relay = await ws;
        let currentUrl = new URL(location.href)
        currentUrl.hash = ""
        currentUrl.search = ""
        currentUrl = currentUrl.href

        // Helper: Check if URL is valid (200 OK) and contains CHECK_STRING
        async function isValidUrl(url) {
            try {
                const response = await fetch(url, { method: 'GET', redirect: 'follow' });
                if (response.status !== 200) return false;
                
                const text = await response.text();
                return text.includes(CHECK_STRING);
            } catch (e) {
                return false;
            }
        }
        function isValidUrlBasic(url){return url.startsWith("https:")} // excludes blob urls

        if (!isMainSite) {
            // Publish Current URL
            const isValid = isValidUrlBasic(currentUrl) && await isValidUrl(currentUrl);
            if (isValid) {
                try {
                    const { finalizeEvent }=await import('https://cdn.jsdelivr.net/npm/nostr-tools@2.25.2/+esm')
                    const idTag = ["d", currentUrl];
                    
                    const event = await finalizeEvent({
                        kind: 30023,
                        created_at: Math.floor(Date.now() / 1000),
                        tags: [idTag, ["t", "mkurlfind2"]],
                        content: "" 
                    }, NSEC);
                    
                    relay.send(JSON.stringify(["EVENT", event]));
                    console.log("Published:", currentUrl);
                } catch (e) {
                    console.error("Publish error:", e);
                }
            } else {
                console.log("Skipped:", currentUrl);
            }
        } else {
            // Fetch Recent URLs if on main website
            const reqId = "req-" + Math.random().toString(36).substr(2, 9);
            let urls = [];
            
            const handler = (e) => {
                const data = JSON.parse(e.data);
                if (data[0] === "EVENT" && data[1] === reqId) {
                    const ev = data[2];
                    // The d-tag IS the URL in this implementation
                    const urlTag = ev.tags.find(t => t[0] === "d");
                    if (urlTag && isValidUrlBasic(urlTag[1])) {
                        urls.push(urlTag[1]);
                    }
                }
                if (urls.length >= 100 || data[0] === "EOSE") {
                    relay.removeEventListener('message', handler);
                    relay.send(JSON.stringify(["CLOSE", reqId]));
                    
                    if (urls.length > 0) {
                        // Uniform random selection
                        const randomIndex = Math.floor(Math.random() * urls.length);
                        const targetUrl = urls[randomIndex];
                        console.log("Redirecting to:", targetUrl);
                        window.location.href = targetUrl;
                    } else {
                        console.log("No URLs found.");
                    }
                }
            };
            
            relay.addEventListener('message', handler);
            
            // Request all recent replaceable events
            relay.send(JSON.stringify([
                "REQ", 
                reqId, 
                { kinds: [30023], "#t":["mkurlfind2"], limit: 100 }
            ]));
        }
    } catch (e) {
        console.error("Connection error:", e);
    }
}

run();
window.findurl=async()=>{
  const ws = new Promise((res) => {
      const w = new WebSocket(RELAY);
      w.onopen = () => res(w);
  });
  const relay=await ws
  relay.addEventListener('message', e=>console.log(e.data));
  relay.send(JSON.stringify([
      "REQ", 
      "req-123",
      { kinds: [30023], "#t":["mkurlfind2"], limit: 100 }
  ]));
}


window.sendError = e => {
if(window.Messages){
try{
Messages.write("§c"+e.substring(0,190))
}catch{}
}
}


}try{document.currentScript.remove()}catch{}
import { createChannel } from '../../core/channel.js';
import { consumeLaunchSplash } from '../../core/splash.js';

consumeLaunchSplash();

/**
 * MineKhan adapter (iPad-friendly: no mouse, keyboard or pointer lock needed).
 *
 * MineKhan's own touch mode stays in charge of walking, placing and hotbar taps
 * on the screen. This file adds the phone: its gyro turns the camera, and A
 * breaks a block.
 *
 * It loads mk/index.html as text, adds four one-line hooks so the game's input
 * functions are reachable from outside, and runs the result in an iframe. The
 * MineKhan files on disk are never edited.
 *
 * URL options:  ?look=5.2  look speed (px of synthetic mouse per degree)
 *               ?invertX=1 / ?invertY=1  flip an axis
 *               ?hold=120  ms that A holds the break button (raise for survival)
 */

const params = new URLSearchParams(location.search);
const PX_PER_DEG = Number(params.get('look')) || 5.2;
const HOLD_MS = Number(params.get('hold')) || 120;
const sx = params.has('invertX') ? -1 : 1;
const sy = params.has('invertY') ? -1 : 1;

const BASE = '/games/minekhan/mk/';
const frame = document.getElementById('mk');
const overlay = document.getElementById('overlay');
const note = document.getElementById('note');

const PATCHES = [
  // Expose the key table, plus look/press/release entry points inside the game's scope.
  ['let Key={}', 'let Key=window.__owKey={}'],
  ['function mmoved(e){',
    'window.__owLook=e=>{if(screen==="play")mmoved(e)};function mmoved(e){'],
  ['function keydown(e){', 'window.__owKeydown=e=>keydown(e);function keydown(e){'],
  ['function keyup(e){', 'window.__owKeyup=e=>keyup(e);function keyup(e){'],
  // Make relative URLs (scripts, maps.json, assets/) resolve inside mk/.
  ['<base href>', `<base href="${BASE}">`],
];

async function loadGame() {
  const res = await fetch(BASE + 'index.html');
  if (!res.ok) throw new Error(`could not load ${BASE}index.html (${res.status})`);
  let html = await res.text();
  for (const [from, to] of PATCHES) {
    const parts = html.split(from);
    if (parts.length !== 2) {
      throw new Error(`MineKhan build has changed: "${from}" found ${parts.length - 1} times, expected 1`);
    }
    html = parts.join(to);
  }
  frame.srcdoc = html;
}

const hooks = () => {
  try {
    const w = frame.contentWindow;
    return w && w.__owLook && w.__owKeydown && w.__owKeyup ? w : null;
  } catch {
    return null;
  }
};

let breaking = false;
function breakBlock() {
  const w = hooks();
  if (!w || breaking) return;
  breaking = true;
  // 'controlName' is MineKhan's own way to press a named control, and it does
  // not flip the game out of touch mode the way a real key press would.
  w.__owKeydown({ type: 'controlName', key: 'break' });
  setTimeout(() => {
    w.__owKeyup({ type: 'controlName', key: 'break' });
    breaking = false;
  }, HOLD_MS);
}

const channel = createChannel({
  onA: breakBlock,
  onSample: (_sample, dt) => {
    const w = hooks();
    if (!w) return;
    const rate = channel.pointer.rateDps;
    // Pointer: +yaw = turning left, +pitch = tilting up.
    // Mouse:   +movementX = look right, +movementY = look down.
    const movementX = -rate.yaw * dt * PX_PER_DEG * sx;
    const movementY = -rate.pitch * dt * PX_PER_DEG * sy;
    if (movementX || movementY) w.__owLook({ movementX, movementY });
  },
});

overlay.addEventListener('click', () => overlay.classList.add('hide'));

loadGame().catch((err) => {
  console.error(err);
  if (note) note.textContent = 'Could not start MineKhan: ' + err.message;
});
